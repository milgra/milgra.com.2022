 //Toth Milan Andras T0EOSA

#include <stdio.h>
#include <stdlib.h>
#define sor 256

struct szotar{char szo[sor]; int kod; struct szotar *elozo,*kov;};

void szotarepit(char szo[sor], struct szotar **gy , struct szotar **elozo)
//A szotar felepitese. Szukseges mind a betomorito, mind a kitomorito rutinhoz.
{
    if (*gy==NULL) //ha nem mutat sehova a pointer
     {
	*gy=(struct szotar *)malloc(sizeof(struct szotar));

	strcpy((*gy)->szo,szo); //szo beletetele

	(*gy)->elozo=*elozo;    //elozo elemre mutat

	if (*elozo==NULL) (*gy)->kod=1;

	else (*gy)->kod=(*gy)->elozo->kod + 1; //hanyadik lesz a sorban, azaz
					       //mi lesz a szo kodja
	(*gy)->kov=NULL;
     }

    else if (strcmp((*gy)->szo,szo)!=0) //ha meg nincs benne a szo a szotarban
	  szotarepit(szo, &(*gy)->kov, &(*gy));
}

int bennevan(char szo[sor], struct szotar **gy)
//ez a fuggveny keresi meg a szo kodjat, ha benne van a szotarban
{
    if (*gy!=NULL)
     {
       if (strcmp((*gy)->szo,szo)==0) return (*gy)->kod;

       bennevan(szo,&(*gy)->kov);
     }

    else return 0;
}

int melyikszo(int szam, struct szotar **gy, char c[sor])
//ez a fuggvemy keresi meg a kodja alapjan a megfelelo szot a szotarban
//a szo hossza a visszateresi erteke, ami 0, ha nincs benne a szo a szotarban
{
    if (*gy!=NULL)
     {
       if ((*gy)->kod==szam)
	{
	  strcpy(c,(*gy)->szo);

	  return(strlen((*gy)->szo));
	}
       else melyikszo(szam,&(*gy)->kov,c);
     }
    else return(0);
}


int kiirkarakter(struct szotar **gy, FILE **ofile)
//miutan kigyujtottuk a karaktereket a szotar elejere, kiirjuk oket a
//fajlunkba, sorrendben, hozzajuk ugyanis szuksegunk van a kitomoritesnel
{
   if (*gy!=NULL)
    {
       fprintf(*ofile,"%c",(*gy)->szo[0]);

       kiirkarakter(&(*gy)->kov,&(*ofile));
    }
}

void nullaztomb(char c[sor],int j)
//a karaktertombot le kell "nullaznom" hogy normalisan lehessen hasznalni
//az ALLOCA-val problemak voltak valamiert a gepemen
   {
    int i;
    for(i=j;i<(sor+1);i++) c[i]=NULL;
   }

int betom(char c[sor], struct szotar **gyoker, int kodhossz, FILE **ifile, FILE **ofile)
{
   int i;
   char seged[sor];

   if (bennevan(c, &(*gyoker)))
	     {
	       strcpy(seged,c);

	       if (fread(&c[kodhossz], 1, 1, *ifile), c[kodhossz]=='\x0')
		 //ha file vege van, kiirom a megmaradt szo kodjat
		 {
		  fprintf(*ofile," %d",bennevan(seged, &(*gyoker)));

		  return;
		 }

	       if (bennevan(c, &(*gyoker))==0)//ha nincs benne a szo, akkor
	       //eloszor kiirom a fajlba az elotte beolvasott szo kodjat,
	       //majd a fuggveny kovetkezo meghivasakor beepul a szotarba
		       fprintf(*ofile," %d",bennevan(seged, &(*gyoker)));

	       betom(c, &(*gyoker), kodhossz + 1, &(*ifile), &(*ofile));
	     }

   else {    //ha nincs benne a szo a szotarban
	 szotarepit(c, &(*gyoker), NULL);

	 c[0]=c[kodhossz-1];//miutan beepitettem az eddig ismeretlen szot,
			    //meg kell jegyeznem az utolso betujet
	 nullaztomb(c,1);

	 betom(c, &(*gyoker), 1, &(*ifile),&(*ofile));//ha beepitettem az uj
					 //szot, termeszetesen a kodhossz
					 //1 rol indul ismet
	}
}

void compress(FILE **ifile, FILE **ofile) //betomorites
{
      struct szotar *gyoker=NULL,*nul=NULL;
      char c[sor];                       //segedsztring
      int i=0;

      while (fread(&c[0], 1, 1, *ifile)) //az elofordulo karakterek
	  {                              //szotarba tetele
	     ++i;

	     nullaztomb(c,1);

	     if (c[0]==' ') {printf("Hohahoo! Ne legyen a szovegben SPACE, mert BEzavarodik a KItomorito!\n");
			     printf("Ez a program csak szemlelteto jellegu.\n");
			     exit(-1);}

	     if (i==128) {printf("Hohahoo! Ne legyen a szoveg hoszabb 128-byte-nal!");
			  printf("Ez a program csak szemlelteto jellegu.\n");
			  exit(-1);}

	     szotarepit(c, &gyoker,&nul);
	   }

      kiirkarakter(&gyoker, &(*ofile)); // akarakterek fajl elejere irasa

      fseek(*ifile , 0, SEEK_SET);      //fajl kezdetere allas

      fread(&c[0], 1, 1, *ifile);       //elso karakter beolvasasa

      nullaztomb(c,1);

      betom(c, &gyoker, 1, &(*ifile), &(*ofile)); //betomorites
}

void decompress(FILE **sfile, FILE **dfile) //kitomorites
{
   struct szotar *gyoker=NULL,*nul=NULL;
   char betu[sor],seged[sor];                      //segedsztringek
   int szam, //a fajlbol beolvasott kod
       volte, //az aktualis szot beolvasta-e mar egyszer
       i;   //segedvaltozo
   int strazsa=0, //strazsa, hanyadik karaktertol kell neznem a betusorozatot
       hossz=0; //a segedvaltozo hossza

   while (fread(&betu[0], 1, 1, *sfile),betu[0]!=' ')
       {     //a karakterek sorrendbeli beolvasasa a fajl elejerol a szotarba
	  betu[1]=NULL; //a tobbi tag nullazasa

	  szotarepit(betu, &gyoker,&nul);
       }

   nullaztomb(seged,1);  //egy sor hossza max 256 karakter lehet
   nullaztomb(betu,1);   //egy kode is, de nagyon kicsi a
					//valoszinusege

   while ( (!(feof(*sfile))) && (fscanf(*sfile," %d",&szam),szam!=EOF))
   //fajl vagy sor vegeig tomoritek ki
   {
	 volte=melyikszo(szam,&gyoker,betu); //ha meg nem fordult elo a
	 //szotarba a szo, azt a melyikszo fuggveny 0-val jelzi, ezt tarolom
	 //a melyiksoz fuggveny a betu stringbe rakja az adott szot, ha nincs
	 // benne a szotarban, akkor a betu tartalma valtozatlan marad, az
	 //elotte beolvasott szo lesz
	 for (i=0;i<strlen(betu);++i) seged[hossz+i]=betu[i];
	 //a segedben tarolom az eddig kitomoritett sort
	 strazsa=megvizsgal(seged, &(*gyoker), strazsa);
	 //megnezi a kimenetet a strazsaelemtol, az ismeretlen szot a
	 //strazsatol a szotarba epiti
	 if (volte==0){ //ha meg nem fordult elo a szo, akkor az elozo
			//megvizsgal fuggveny mar belerakta a szotarba, de
			//nekem vissza kell fejtenem az elozo allapotig
			//a kimenetet, es oda kell szurnom
		       melyikszo(szam,&gyoker,betu);

		       for (i=0;i<strlen(betu);++i) seged[hossz+i]=betu[i];

		      }

	 hossz=strlen(seged); //a kimenet(sor) hossza
       }

fprintf(*dfile,"%s",seged); //kiirom a kimenetsort a fajlba
}

int megvizsgal(char *seged, struct szotar **gyoker, int strazsa)
//megnezi, hogy az adott szo benne van e a szotarban, ha nincs, belerakja
{
   int i,hossz;
   char help[sor]; //segedsztring

   nullaztomb(help,1);

   hossz=strlen(seged);

   for (i=strazsa;i<hossz;++i) //a strazsaelemtol nezi a sor vegeig a
     {                         //lehetseges uj szavakat
       help[i-strazsa]=seged[i];
       if (bennevan(help, &gyoker)==0) //ha az uj szo nincs benne a szotarban
	{
	  szotarepit(help, &gyoker, NULL);//beleteszi
	  break; //kilep a ciklusbol, nem kell tovabb nezni
	}
   }
   return (strazsa+strlen(help)-1); // a sor utolso karaktere=strazsaelem
}


int main(int argc, char *argv[])
{
    FILE *file1, *file2;

    if ( argv[1][0] != 'a' && argv[1][0] != 'x')
       { printf("\n LKW! Adattomorito (c) Toth Milan Andras");
	 printf("\n Hasznalat: LKW [utasitas] [fajl1] [fajl2]");
	 printf("\n Utasitas: [a] - betomorites");
	 printf("\n           [x] - kitomorites");
	 return(-1);
       }

     switch (argv[1][0]){
     case 'a' :         //betomorites
	{
	   if (!(file1 = fopen(argv[2], "r")))
	      {
		fprintf(stderr, "\nError open input data file!\n");
		return(-1);
	      }
	   else

	   if (!(file2 = fopen(argv[3], "w")))
	      {
		fprintf(stderr, "\nError open output data file!\n");
		return(-1);
	      }
	   else
	      {
		compress(&file1, &file2);
		fclose(file1);
		fclose(file2);
	      };
	break;
	};

    case 'x' :          //kitomorites
	{
	   if (!(file1 = fopen(argv[2], "r")))
	      {
		fprintf(stderr, "\nError open input data file!\n");
		return(-1);
	      }
	   else

	   if (!(file2 = fopen(argv[3], "w")))
	      {
		fprintf(stderr, "\nError open output data file!\n");
		return(-1);
	      }
	   else
	      {
		decompress(&file1, &file2);
		fclose(file1);
		fclose(file2);
	      };
	break;
	};
    }
    return 0;

}



